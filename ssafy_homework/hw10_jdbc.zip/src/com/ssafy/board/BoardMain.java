package com.ssafy.board;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class BoardMain {
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		BoardMain bm = new BoardMain();
		
	}
	public void menu() {
		
	}
	
	public void registerArticle() {
		
	}
	
	public void searchListAll() {
		
	}
	
	public void searchlistBySubject() {
		
	}
	
	public void viewArticle() {
		
	}
	
	public void modifyArticle() {
		
	}
	
	public void deleteArticle() {
		
	}
}